var searchData=
[
  ['active',['active',['../struct_scheduling_struct.html#aa47e1a57958efc44c5d5c1a2b3962d5a',1,'SchedulingStruct']]]
];
