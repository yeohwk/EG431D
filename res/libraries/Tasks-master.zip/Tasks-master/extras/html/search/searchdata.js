var indexSectionsWithContent =
{
  0: "mt",
  1: "t",
  2: "t",
  3: "t",
  4: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "typedefs",
  4: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Typedefs",
  4: "Macros"
};

