var searchData=
[
  ['max_5ftask_5fcnt',['MAX_TASK_CNT',['../_tasks_8h.html#a544da5c693eaab178a8138e7ac27ad99',1,'Tasks.h']]]
];
