var searchData=
[
  ['task',['Task',['../_tasks_8h.html#a43925087945f12bbd3cfd17b6a2a3e13',1,'Tasks.h']]]
];
