var searchData=
[
  ['ptr_5fnon_5fstatic_5fmethod',['PTR_NON_STATIC_METHOD',['../_tasks_8h.html#add4514b8d4b89a464b0fbeab898218f7',1,'Tasks.h']]]
];
