var _tasks_8cpp =
[
    [ "Tasks_Add", "_tasks_8cpp.html#abcd73ae8d50ad3929a21a5dfdb269bf4", null ],
    [ "Tasks_Clear", "_tasks_8cpp.html#ad0f9e9096fe29465d37175d88f918370", null ],
    [ "Tasks_Delay", "_tasks_8cpp.html#a69a28492d0bbe6402e632c04de6f8b40", null ],
    [ "Tasks_Init", "_tasks_8cpp.html#a5b0ac193b3ae2f2f7cfd5dc7a66c811b", null ],
    [ "Tasks_Pause", "_tasks_8cpp.html#aa5521fb12d15b22fd08dfe78eaf0eabd", null ],
    [ "Tasks_Remove", "_tasks_8cpp.html#a38461dee754ff5ee43f718fbbad0ed89", null ],
    [ "Tasks_SetState", "_tasks_8cpp.html#afeaa615f429dfec3a600104e3777d9ea", null ],
    [ "Tasks_Start", "_tasks_8cpp.html#aee9e99dc76d2f8ad7c7eb22c6e709271", null ]
];