var files =
[
    [ "Tasks.cpp", "_tasks_8cpp.html", "_tasks_8cpp" ],
    [ "Tasks.h", "_tasks_8h.html", "_tasks_8h" ]
];