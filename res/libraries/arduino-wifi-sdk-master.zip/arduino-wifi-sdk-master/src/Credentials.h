#ifndef CREDENTIALS_H_
#define CREDENTIALS_H_

class Credentials {
};

#endif
